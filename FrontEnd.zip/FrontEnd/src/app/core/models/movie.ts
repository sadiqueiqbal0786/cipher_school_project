export interface Movie {
    title: string;
    director: string;
    releaseDate: string;
    releaseDateDate: Date;
    type: string;
    id: number;
}
